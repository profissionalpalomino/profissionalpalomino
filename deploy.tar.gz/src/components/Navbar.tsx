import { Hexagon, MessageCircle } from "lucide-react";
import { Button } from "@/components/ui/button";

const WHATSAPP = "5531984773813";

const Navbar = () => {
  const scrollTo = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: "smooth" });
    }
  };

  return (
    <header className="fixed top-0 left-0 right-0 z-50 bg-background/60 backdrop-blur-xl border-b border-white/5">
      <div className="max-w-7xl mx-auto px-5 lg:px-8">
        <div className="flex h-20 items-center justify-between">
          {/* Logo */}
          <div className="flex items-center gap-3 cursor-pointer" onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}>
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-primary/20 border border-primary/30 shadow-[0_0_20px_hsl(var(--primary)/0.2)]">
              <Hexagon className="h-6 w-6 text-primary fill-primary/10" />
            </div>
            <span className="text-xl font-extrabold tracking-tight text-foreground">
              Palomino <span className="text-primary">Tech</span>
            </span>
          </div>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center gap-8">
            <button onClick={() => scrollTo("servicos")} className="text-sm font-medium text-muted-foreground hover:text-foreground transition-colors">Serviços</button>
            <button onClick={() => scrollTo("processo")} className="text-sm font-medium text-muted-foreground hover:text-foreground transition-colors">Processo</button>
            <Button
              size="sm"
              asChild
              className="bg-primary/10 text-primary hover:bg-primary hover:text-primary-foreground border border-primary/30 transition-all rounded-full px-5"
            >
              <a
                href={`https://wa.me/${WHATSAPP}?text=Olá! Quero transformar meu negócio com a Palomino Tech.`}
                target="_blank"
                rel="noopener noreferrer"
              >
                <MessageCircle className="mr-2 h-4 w-4" />
                Falar Conosco
              </a>
            </Button>
          </nav>
        </div>
      </div>
    </header>
  );
};

export default Navbar;
