import AnimatedSection from "./AnimatedSection";
import { Button } from "@/components/ui/button";
import { MessageCircle, Mail } from "lucide-react";

const WHATSAPP = "5531984773813";

const CtaSection = () => {
  return (
    <section className="section-padding relative overflow-hidden" style={{ background: "var(--gradient-hero)" }}>
      {/* Glowing orb */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[500px] h-[500px] rounded-full bg-primary/10 blur-[150px]" />
      
      <div className="container-narrow text-center relative z-10">
        <AnimatedSection>
          <h2 className="text-3xl font-extrabold text-foreground sm:text-4xl md:text-5xl lg:text-5xl">
            Pronto para transformar<br className="hidden sm:block" /> a sua operação?
          </h2>
          <p className="mt-4 text-muted-foreground text-lg max-w-xl mx-auto">
            Vamos conversar sobre os desafios do seu negócio e desenhar a solução ideal juntos.
          </p>
          
          <div className="mt-10 flex flex-col sm:flex-row gap-4 justify-center">
            <Button
              size="lg"
              asChild
              className="bg-primary text-primary-foreground hover:brightness-110 text-base font-bold px-8 py-6 rounded-xl shadow-[var(--shadow-glow)] transition-all duration-300"
            >
              <a
                href={`https://wa.me/${WHATSAPP}?text=Olá! Gostaria de falar sobre um projeto de desenvolvimento para o meu negócio.`}
                target="_blank"
                rel="noopener noreferrer"
              >
                <MessageCircle className="mr-2 h-5 w-5" />
                Entrar em contato
              </a>
            </Button>
            
            <Button
              size="lg"
              asChild
              variant="outline"
              className="border-border text-foreground bg-card/10 hover:bg-card/30 text-base font-bold px-8 py-6 rounded-xl backdrop-blur-sm transition-all"
            >
              <a href="mailto:profissionalpalomino@gmail.com">
                <Mail className="mr-2 h-5 w-5" />
                Enviar e-mail
              </a>
            </Button>
          </div>
        </AnimatedSection>
      </div>
    </section>
  );
};

export default CtaSection;
