import { useState } from "react";
import AnimatedSection from "./AnimatedSection";
import { CheckCircle2, ChevronLeft, ChevronRight, ExternalLink } from "lucide-react";

const projects = [
  {
    title: "Barbearias Finder",
    description:
      "Localizador automatizado de barbearias com extração de dados e integração direta ao WhatsApp. Uma ferramenta essencial para escalar prospecção comercial.",
    functions: ["Automação & Scraping", "Disparo de Mensagens", "Gestão de Leads"],
    link: "https://palomino-site-barbearias-finder.jzkgdj.easypanel.host",
    screenshots: ["/screenshot-barbearias-finder.png"],
    tag: "SaaS Tool",
  },
  {
    title: "Finanças Pro",
    description:
      "Plataforma web de gestão financeira com notificações e lembretes inteligentes via WhatsApp, construída para simplificar cobranças e pagamentos.",
    functions: ["Dashboard Financeiro", "Gestão de Usuários", "Cron Jobs e Alertas"],
    link: "https://financaspro.profissionalpalomino.cloud",
    screenshots: ["/screenshot-financas-pro.png"],
    tag: "Plataforma Web",
  },
  {
    title: "Palomino Instagram",
    description:
      "Sistema inovador com múltiplos agentes de IA que conversam entre si para planejar, criar e publicar posts no Instagram de forma autônoma, sem intervenção humana.",
    functions: ["Multi-Agentes de IA", "Criação de Conteúdo Autônoma", "Automação de Redes Sociais"],
    link: "#",
    screenshots: ["/screenshot-palomino-instagram.png"],
    tag: "IA Multi-Agentes",
  },
];

function Carousel({ images }: { images: string[] }) {
  const [idx, setIdx] = useState(0);
  const prev = () => setIdx((i) => (i - 1 + images.length) % images.length);
  const next = () => setIdx((i) => (i + 1) % images.length);

  return (
    <div className="relative w-full overflow-hidden rounded-xl aspect-video bg-black/40 group">
      <img
        src={images[idx]}
        alt="Screenshot do projeto"
        className="w-full h-full object-cover object-top transition-all duration-500"
      />
      <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent" />

      {images.length > 1 && (
        <>
          <button
            onClick={prev}
            className="absolute left-2 top-1/2 -translate-y-1/2 p-1.5 rounded-full bg-black/50 text-white opacity-0 group-hover:opacity-100 transition-opacity hover:bg-primary/80"
          >
            <ChevronLeft className="h-4 w-4" />
          </button>
          <button
            onClick={next}
            className="absolute right-2 top-1/2 -translate-y-1/2 p-1.5 rounded-full bg-black/50 text-white opacity-0 group-hover:opacity-100 transition-opacity hover:bg-primary/80"
          >
            <ChevronRight className="h-4 w-4" />
          </button>
          <div className="absolute bottom-2 left-1/2 -translate-x-1/2 flex gap-1.5">
            {images.map((_, i) => (
              <button
                key={i}
                onClick={() => setIdx(i)}
                className={`w-1.5 h-1.5 rounded-full transition-all ${
                  i === idx ? "bg-primary w-3" : "bg-white/50"
                }`}
              />
            ))}
          </div>
        </>
      )}
    </div>
  );
}

const ProjectsSection = () => {
  return (
    <section className="section-padding dark-section relative">
      <div className="container-narrow">
        <AnimatedSection>
          <div className="text-center">
            <span className="inline-block rounded-full bg-primary/10 px-4 py-1.5 text-sm font-semibold text-primary mb-4">
              Portfólio
            </span>
            <h2 className="text-2xl font-extrabold sm:text-3xl md:text-4xl lg:text-5xl mb-6">
              Projetos que já desenvolvi
            </h2>
            <p className="mx-auto max-w-2xl text-lg text-muted-foreground">
              Veja alguns dos sistemas e soluções que construí para resolver problemas reais através de automação e design premium.
            </p>
          </div>
        </AnimatedSection>

        <div className="mt-16 grid gap-8 md:grid-cols-2 lg:grid-cols-3">
          {projects.map((project, i) => (
            <AnimatedSection key={i} delay={i * 0.15}>
              <div className="group glass-card h-full flex flex-col transition-all duration-300 hover:border-primary/30 overflow-hidden">
                {/* Screenshot carousel */}
                <div className="p-4 pb-0">
                  <Carousel images={project.screenshots} />
                </div>

                {/* Content */}
                <div className="p-6 flex flex-col flex-grow">
                  <div className="flex items-start justify-between mb-3">
                    <div>
                      <span className="text-xs font-semibold text-primary uppercase tracking-wider">{project.tag}</span>
                      <h3 className="text-xl font-bold text-foreground mt-1">{project.title}</h3>
                    </div>
                    {project.link !== "#" && (
                      <a
                        href={project.link}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-muted-foreground hover:text-primary transition-colors mt-1 shrink-0"
                        aria-label={`Acessar ${project.title}`}
                      >
                        <ExternalLink className="h-4 w-4" />
                      </a>
                    )}
                  </div>

                  <p className="text-muted-foreground text-sm mb-6 flex-grow">
                    {project.description}
                  </p>

                  <div>
                    <p className="text-xs font-semibold text-foreground uppercase tracking-wider mb-3">
                      Funções Principais
                    </p>
                    <ul className="space-y-2">
                      {project.functions.map((func, j) => (
                        <li key={j} className="flex items-center gap-2">
                          <CheckCircle2 className="h-4 w-4 text-primary shrink-0" />
                          <span className="text-sm font-medium text-foreground/90">{func}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
              </div>
            </AnimatedSection>
          ))}
        </div>
      </div>
    </section>
  );
};

export default ProjectsSection;
