import AnimatedSection from "./AnimatedSection";
import { MonitorSmartphone, Code2, Bot, Database, CloudCog, ShieldCheck } from "lucide-react";

const services = [
  { icon: Code2, title: "Sistemas Web Sob Medida", desc: "Plataformas, painéis e CRMs desenvolvidos especificamente para o fluxo do seu negócio.", color: "from-rose-500/20 to-pink-500/10" },
  { icon: MonitorSmartphone, title: "Aplicativos Mobile", desc: "Apps nativos e híbridos de alta performance para iOS e Android.", color: "from-pink-500/20 to-rose-500/10" },
  { icon: Bot, title: "Automação de Processos (RPA)", desc: "Robôs que eliminam trabalho manual, integram sistemas e aceleram a operação.", color: "from-rose-500/20 to-red-500/10" },
  { icon: Database, title: "Arquitetura de Dados", desc: "Estruturação, migração e otimização de bancos de dados complexos.", color: "from-red-500/20 to-rose-500/10" },
  { icon: CloudCog, title: "Integrações via API", desc: "Conectamos os softwares que você já usa para trabalharem juntos sem fricção.", color: "from-rose-600/20 to-pink-600/10" },
  { icon: ShieldCheck, title: "Sustentação e Suporte", desc: "Manutenção evolutiva, monitoramento 24/7 e garantia de estabilidade.", color: "from-pink-600/20 to-rose-600/10" },
];

const ServicesSection = () => {
  return (
    <section id="servicos" className="section-padding dark-section relative overflow-hidden bg-background">
      {/* Grid pattern overlay */}
      <div className="absolute inset-0 bg-grid-pattern opacity-50" />
      
      <div className="container-narrow relative z-10">
        <AnimatedSection>
          <div className="text-center">
            <span className="inline-block rounded-full border border-primary/30 bg-primary/10 px-4 py-1.5 text-sm font-semibold text-primary mb-4">
              Expertise Técnica
            </span>
            <h2 className="text-3xl font-extrabold sm:text-4xl md:text-5xl lg:text-5xl text-foreground">
              Como podemos ajudar sua empresa
            </h2>
            <p className="mt-4 text-muted-foreground text-lg max-w-2xl mx-auto">
              Desenvolvemos produtos digitais robustos, do código-fonte à infraestrutura na nuvem.
            </p>
          </div>
        </AnimatedSection>

        <div className="mt-16 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {services.map((s, i) => (
            <AnimatedSection key={i} delay={i * 0.08}>
              <div className="group relative overflow-hidden rounded-2xl border border-border bg-card/40 backdrop-blur-sm p-8 transition-all duration-300 hover:border-primary/50 hover:bg-card/60 hover:shadow-[var(--shadow-glow)]">
                {/* Gradient accent */}
                <div className={`absolute top-0 left-0 w-full h-1 bg-gradient-to-r ${s.color}`} />
                
                <div className="mb-6 flex h-14 w-14 items-center justify-center rounded-xl bg-primary/10 border border-primary/20">
                  <s.icon className="h-7 w-7 text-primary" />
                </div>
                <h3 className="text-xl font-bold text-foreground">{s.title}</h3>
                <p className="mt-3 text-sm text-muted-foreground leading-relaxed">{s.desc}</p>
              </div>
            </AnimatedSection>
          ))}
        </div>
      </div>
    </section>
  );
};

export default ServicesSection;
