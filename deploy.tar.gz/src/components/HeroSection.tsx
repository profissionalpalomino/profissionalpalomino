import { motion } from "framer-motion";
import { ArrowRight, Hexagon } from "lucide-react";
import { Button } from "@/components/ui/button";

const WHATSAPP = "5531984773813";

const HeroSection = () => {
  return (
    <section className="relative overflow-hidden min-h-screen flex items-center bg-background">
      {/* Background gradients */}
      <div className="absolute inset-0 bg-gradient-to-br from-background via-[hsl(344,33%,11%)/0.8] to-background" />
      
      {/* Floating orbs */}
      <div className="absolute top-20 right-[15%] w-[400px] h-[400px] rounded-full bg-primary/10 blur-[120px] animate-pulse" />
      <div className="absolute bottom-20 left-[10%] w-[500px] h-[500px] rounded-full bg-primary/5 blur-[150px]" />

      <div className="container-narrow relative z-10 py-20">
        <motion.div
          initial={{ opacity: 0, y: 40 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, ease: "easeOut" }}
          className="max-w-4xl"
        >
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.2, duration: 0.5 }}
            className="inline-flex items-center gap-2 rounded-full border border-primary/30 bg-primary/10 backdrop-blur-sm px-4 py-2 text-sm font-semibold text-primary mb-8"
          >
            <span className="relative flex h-3 w-3">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-primary opacity-75"></span>
              <span className="relative inline-flex rounded-full h-3 w-3 bg-primary"></span>
            </span>
            Inovação em Software
          </motion.div>

          <h1 className="text-4xl font-extrabold leading-[1.1] tracking-tight sm:text-5xl md:text-6xl lg:text-7xl text-foreground">
            Soluções em Software e Automação para{" "}
            <span className="text-gradient animate-text-gradient bg-[length:200%_auto]">impulsionar seu negócio</span>.
          </h1>

          <p className="mt-6 text-lg leading-relaxed text-muted-foreground md:text-xl max-w-2xl">
            Desenvolvemos softwares sob medida, aplicações web/mobile e automações inteligentes que reduzem custos e escalam seus resultados.
          </p>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.5, duration: 0.5 }}
            className="mt-10 flex flex-col gap-4 sm:flex-row"
          >
            <Button
              size="lg"
              asChild
              className="bg-primary text-primary-foreground hover:brightness-110 text-base font-bold px-8 py-6 rounded-xl shadow-[var(--shadow-glow)] transition-all duration-300 hover:shadow-[0_0_60px_hsl(350_89%_60%/0.35)]"
            >
              <a
                href={`https://wa.me/${WHATSAPP}?text=Olá! Quero transformar meu negócio com a Palomino Tech.`}
                target="_blank"
                rel="noopener noreferrer"
              >
                Entrar em contato
                <ArrowRight className="ml-2 h-5 w-5" />
              </a>
            </Button>
          </motion.div>

          {/* Stats bar */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.7, duration: 0.5 }}
            className="mt-16 flex flex-wrap gap-8 md:gap-12"
          >
            {[
              { value: "100%", label: "Sob medida" },
              { value: "24/7", label: "Aplicações escaláveis" },
              { value: "Alta", label: "Performance técnica" },
            ].map((stat, i) => (
              <div key={i} className="text-left border-l-2 border-primary/40 pl-4">
                <p className="text-2xl font-extrabold text-foreground md:text-3xl">{stat.value}</p>
                <p className="text-sm text-muted-foreground mt-1 font-medium">{stat.label}</p>
              </div>
            ))}
          </motion.div>
        </motion.div>
      </div>

      {/* Bottom fade */}
      <div className="absolute bottom-0 left-0 right-0 h-32 bg-gradient-to-t from-background to-transparent" />
    </section>
  );
};

export default HeroSection;
