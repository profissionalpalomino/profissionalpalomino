import { Mail, MessageCircle, Hexagon } from "lucide-react";

const WHATSAPP = "5531984773813";

const Footer = () => {
  return (
    <footer className="bg-background border-t border-border py-12 px-5 relative z-10">
      <div className="max-w-6xl mx-auto flex flex-col md:flex-row items-center justify-between gap-6">
        <div className="flex items-center gap-3">
          <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-primary/20 border border-primary/30">
            <Hexagon className="h-7 w-7 text-primary fill-primary/10" />
          </div>
          <span className="text-2xl font-extrabold tracking-tight text-foreground">
            Palomino <span className="text-primary">Tech</span>
          </span>
        </div>
        <p className="text-sm text-muted-foreground">© {new Date().getFullYear()} — Todos os direitos reservados</p>
        <div className="flex items-center gap-6 text-sm">
          <a href={`https://wa.me/${WHATSAPP}`} target="_blank" rel="noopener noreferrer" className="flex items-center gap-2 text-muted-foreground hover:text-primary transition-colors">
            <MessageCircle className="h-4 w-4" />
            WhatsApp
          </a>
          <a href="mailto:profissionalpalomino@gmail.com" className="flex items-center gap-2 text-muted-foreground hover:text-primary transition-colors">
            <Mail className="h-4 w-4" />
            E-mail
          </a>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
